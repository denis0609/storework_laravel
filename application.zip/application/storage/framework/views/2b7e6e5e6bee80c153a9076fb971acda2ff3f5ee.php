<div class="ui modal medium add">
    <div class="header"><?php echo e(__("Request Leave")); ?></div>
    <div class="content">
        <form id="request_personal_leave_form" action="<?php echo e(url('personal/leaves/request')); ?>" class="ui form" method="post" accept-charset="utf-8">
        <?php echo csrf_field(); ?>
        <div class="field">
            <label><?php echo e(__("Leave Type")); ?></label>
            <select class="ui dropdown uppercase getid" name="type">
                <option value="">Select Type</option>
                <?php if(isset($lt)): ?>
                    <?php $__currentLoopData = $lt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $rights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p == $data->id): ?>
                                <option value="<?php echo e($data->leavetype); ?>" data-id="<?php echo e($data->id); ?>"><?php echo e($data->leavetype); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="two fields">
            <div class="field">
                <label for=""><?php echo e(__("Leave from")); ?></label>
                <input id="leavefrom" type="text" placeholder="Start date" name="leavefrom" class="airdatepicker uppercase" />
            </div>
            <div class="field">
                <label for=""><?php echo e(__("Leave to")); ?></label>
                <input id="leaveto" type="text" placeholder="End date" name="leaveto" class="airdatepicker uppercase" />
            </div>
        </div>
        <div class="field">
            <label for=""><?php echo e(__("Return Date")); ?></label>
            <input id="returndate" type="text" placeholder="Enter Return date" name="returndate" class="airdatepicker uppercase" />
        </div>
        <div class="field">
            <label><?php echo e(__("Reason")); ?></label>
            <textarea class="uppercase" rows="5" name="reason" value=""></textarea>
        </div>
        <div class="field">
            <div class="ui error message">
                <i class="close icon"></i>
                <div class="header"></div>
                <ul class="list">
                    <li class=""></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="actions">
        <input type="hidden" name="typeid" value="">
        <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Send Request")); ?></button>
        <button class="ui grey small button cancel" type="button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></button>
    </div>
    </form>
</div><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/personal/modals/modal-request-leave.blade.php ENDPATH**/ ?>