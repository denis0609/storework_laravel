    <?php $__env->startSection('meta'); ?>
        <title>Employee Roles | Workday Time Clock</title>
        <meta name="description" content="Workday roles, view all employee roles, add roles, edit roles, and delete roles.">
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-roles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.modals.modal-edit-role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__("User Roles")); ?>

                <button class="ui positive button mini offsettop5 btn-add float-right"><i class="ui icon plus"></i><?php echo e(__("Add")); ?></button>
                <a href="<?php echo e(url('users')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i><?php echo e(__("Return")); ?></a>
            </h2>
        </div>

        <div class="row">
            <?php if($errors->any()): ?>
            <div class="ui error message">
                <i class="close icon"></i>
                <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                <ul class="list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__("Role Name")); ?></th>
                                <th><?php echo e(__("Status")); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($roles)): ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($role->role_name); ?></td>
                                    <td><?php echo e($role->state); ?></td>
                                    <td class="align-right">
                                        <a href="<?php echo e(url('/users/roles/permissions/edit')); ?>/<?php echo e($role->id); ?>" class="ui circular basic icon button tiny">
                                        <i class="ui icon tasks"></i></a>
                                        <button type="button" class="ui circular basic icon button tiny btn-edit" data-id="<?php echo e($role->id); ?>"><i class="icon edit outline"></i></button>
                                        <a href="<?php echo e(url('/users/roles/delete/'.$role->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    
    $('.btn-edit').click(function(event) {
        var id = $(this).attr('data-id');
        var url = $("#_url").val();
        $.ajax({
            url: url + '/user/roles/get/',type: 'get',dataType: 'json',data: {id: id},headers: { 'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') },
            success: function(response) {
                $state = response['state'];
                $('.edit input[name="id"]').val(response['id']);
                $('.edit input[name="role_name"]').val(response['role_name']);
                if ($state == 'Active') {
                    $('.ui.dropdown.state').dropdown({values: [{name: 'Active',value: 'Active', selected : true},{name: 'Disabled',value: 'Disabled'}]});
                } else if($state == 'Disabled') {
                    $('.ui.dropdown.state').dropdown({values: [{name: 'Active',value: 'Active'},{name: 'Disabled',value: 'Disabled', selected : true}]});
                } 
                $('ui.modal.edit').modal('show');
            }
        })
    });
    </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/employee-roles.blade.php ENDPATH**/ ?>