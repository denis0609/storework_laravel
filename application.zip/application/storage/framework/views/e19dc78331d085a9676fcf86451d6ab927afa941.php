    <?php $__env->startSection('meta'); ?>
        <title>My Dashboard | Workday Time Clock</title>
        <meta name="description" content="Workday my dashboard, view recent attendance, view recent leave of absence, and view previous schedules">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <h2 class="page-title"><?php echo e(__("Dashboard")); ?></h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="ui icon clock outline"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text"><span class="uppercase"><?php echo e(__("Attendance (Current Month)")); ?></span></span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-green" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__("Late Arrivals")); ?></td>
                                            <td><span class="bolder"><?php if(isset($la)): ?> <?php echo e($la); ?> <?php endif; ?></span></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__("Early Departures")); ?></td>
                                            <td><span class="bolder"><?php if(isset($ed)): ?> <?php echo e($ed); ?> <?php endif; ?></span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="ui icon user circle"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text"><?php echo e(__("Present Schedule")); ?></span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-aqua" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__("Time")); ?></td>
                                            <td>
                                                <span class="bolder">
                                                    <?php if(isset($cs)): ?>
                                                        <?php
                                                        if ($cs->intime != null && $cs->outime != null) {
                                                            if ($tf == 1) {
                                                                echo e(date("h:i A", strtotime($cs->intime)));
                                                                echo e(" - ");
                                                                echo e(date("h:i A", strtotime($cs->outime)));
                                                            } else {
                                                                echo e(date("H:i", strtotime($cs->intime)));
                                                                echo e(" - ");
                                                                echo e(date("H:i", strtotime($cs->outime)));
                                                            }
                                                        }
                                                        ?>
                                                    <?php endif; ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__("Rest Days")); ?></td>
                                            <td><span class="bolder"><?php if(isset($cs->restday)): ?> <?php echo e($cs->restday); ?> <?php endif; ?></span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="info-box">
                    <span class="info-box-icon bg-orange"><i class="ui icon home"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text uppercase"><?php echo e(__("Leaves of Absence")); ?></span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-orange" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__("Approved")); ?> </td>
                                            <td><span class="bolder"><?php if(isset($al)): ?><?php echo e($al); ?><?php endif; ?></span></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__("Pending")); ?> </td>
                                            <td><span class="bolder"><?php if(isset($pl)): ?><?php echo e($pl); ?><?php endif; ?></span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(__("Recent Attendances")); ?></h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left"><?php echo e(__("Date")); ?></th>
                                <th class="text-left"><?php echo e(__("Time")); ?></th>
                                <th class="text-left"><?php echo e(__("Description")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($a)): ?>
                            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($v->timein != '' && $v->timeout == ''): ?>
                            <tr>
                                <td>
                                    <?php echo e(date('M d, Y', strtotime($v->date))); ?>
                                </td>
                                <td>
                                    <?php
                                        if($tf == 1) {
                                            echo e(date("h:i:s A", strtotime($v->timein)));
                                        } else {
                                            echo e(date("H:i:s", strtotime($v->timein)));
                                        }
                                    ?>
                                </td>
                                <td>Time-In</td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if($v->timein != '' && $v->timeout != ''): ?>
                            <tr>
                                <td>
                                    <?php echo e(date('M d, Y', strtotime($v->date))); ?>
                                </td>
                                <td>
                                    <?php
                                        if($tf == 1) {
                                            echo e(date("h:i:s A", strtotime($v->timeout)));
                                        } else {
                                            echo e(date("H:i:s", strtotime($v->timeout)));
                                        }
                                    ?>
                                </td>
                                <td>Time-Out</td>
                            </tr>
                            <?php endif; ?>

                            <?php if($v->timein != '' && $v->timeout != ''): ?>
                            <tr>
                                <td>
                                    <?php echo e(date('M d, Y', strtotime($v->date))); ?>
                                </td>
                                <td>
                                    <?php
                                        if($tf == 1) {
                                            echo e(date("h:i:s A", strtotime($v->timein)));
                                        } else {
                                            echo e(date("H:i:s", strtotime($v->timein)));
                                        }
                                    ?>
                                </td>
                                <td>Time-In</td>
                            </tr>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(__("Previous Schedules")); ?></h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                    <table class="table table-striped nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left"><?php echo e(__("Time")); ?></th>
                                <th class="text-left"><?php echo e(__("From Date / Until")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($ps)): ?>
                            <?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php
                                        if ($s->intime != null && $s->outime != null) {
                                            if ($tf == 1) {
                                                echo e(date("h:i A", strtotime($s->intime)));
                                                echo e(" - ");
                                                echo e(date("h:i A", strtotime($s->outime)));
                                            } else {
                                                echo e(date("H:i", strtotime($s->intime)));
                                                echo e(" - ");
                                                echo e(date("H:i", strtotime($s->outime)));
                                            }
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                        echo e(date('M d',strtotime($s->datefrom)).' - '.date('M d, Y',strtotime($s->dateto)));
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            
            <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(__("Recent Leaves of Absence")); ?></h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                    <table class="table table-striped nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left"><?php echo e(__("Description")); ?></th>
                                <th class="text-left"><?php echo e(__("Date")); ?></th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php if(isset($ald)): ?>
                                <?php $__currentLoopData = $ald; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($l->type); ?></td>
                                    <td>
                                        <?php
                                            $fd = date('M', strtotime($l->leavefrom));
                                            $td = date('M', strtotime($l->leaveto));

                                            if($fd == $td){
                                                $var = date('M d', strtotime($l->leavefrom)) .' - '. date('d, Y', strtotime($l->leaveto));
                                            } else {
                                                $var = date('M d', strtotime($l->leavefrom)) .' - '. date('M d, Y', strtotime($l->leaveto));
                                            }
                                        ?>
                                        <?php echo e($var); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                    </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/personal/personal-dashboard.blade.php ENDPATH**/ ?>