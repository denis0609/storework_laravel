    <?php $__env->startSection('meta'); ?>
        <title>Reports | Workday Time Clock</title>
        <meta name="description" content="Workday reports, view reports, and export or download reports.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__("Employee Schedule Report")); ?>

                <a href="<?php echo e(url('reports')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i><?php echo e(__("Return")); ?></a>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body reportstable">
                    <form action="<?php echo e(url('export/report/schedule')); ?>" method="post" accept-charset="utf-8" class="ui small form form-filter" id="filterform">
                        <?php echo csrf_field(); ?>
                        <div class="inline three fields">
                            <div class="three wide field">
                                <select name="employee" class="ui search dropdown getid">
                                    <option value=""><?php echo e(__("Employee")); ?></option>
                                    <?php if(isset($employee)): ?>
                                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->lastname); ?>, <?php echo e($e->firstname); ?>" data-id="<?php echo e($e->idno); ?>"><?php echo e($e->lastname); ?>, <?php echo e($e->firstname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <input type="hidden" name="emp_id" value="">
                            <button id="btnfilter" class="ui icon button positive small inline-button"><i class="ui icon filter alternate"></i> <?php echo e(__("Filter")); ?></button>
                            <button type="submit" name="submit" class="ui icon button blue small inline-button"><i class="ui icon download"></i> <?php echo e(__("Download")); ?></button>
                        </div>
                    </form>

                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__("Employee Name")); ?></th>
                                <th><?php echo e(__("Start Time")); ?></th>
                                <th><?php echo e(__("Off Time")); ?></th>
                                <th><?php echo e(__("Start Date")); ?> </th>
                                <th><?php echo e(__("End Date")); ?></th>
                                <th><?php echo e(__("Hours")); ?></th>
                                <th><?php echo e(__("Rest Days")); ?></th>
                                <th><?php echo e(__("Status")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($empSched)): ?>
                            <?php $__currentLoopData = $empSched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($v->employee); ?></td>
                                    <td>
                                        <?php
                                            if($v->intime != null) {
                                                if($tf == 1) {
                                                    echo e(date('h:i A', strtotime($v->intime)));
                                                } else {
                                                    echo e(date('H:i ', strtotime($v->intime)));
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            if($v->outime != null) {
                                                if($tf == 1) {
                                                    echo e(date('h:i A', strtotime($v->outime)));
                                                } else {
                                                    echo e(date('H:i ', strtotime($v->outime)));
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            echo e(date("l, F j, Y", strtotime($v->datefrom)));
                                        ?> 
                                    </td>
                                    <td>
                                        <?php 
                                            echo e(date("l, F j, Y", strtotime($v->dateto)));
                                        ?> 
                                    </td>
                                    </td>
                                    <td><?php echo e($v->hours); ?></td>
                                    <td><?php echo e($v->restday); ?></td>
                                    <td>
                                        <?php if($v->archive == '0'): ?> 
                                            <span class="green">Present Schedule</span>
                                        <?php else: ?>
                                            <span class="teal">Past Schedule</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: false,ordering: true});

    // transfer idno 
    $('.ui.dropdown.getid').dropdown({ onChange: function(value, text, $selectedItem) {
        $('select[name="employee"] option').each(function() {
            if($(this).val()==value) {var id = $(this).attr('data-id');$('input[name="emp_id"]').val(id);};
        });
    }});

    $('#btnfilter').click(function(event) {
        event.preventDefault();
        var emp_id = $('input[name="emp_id"]').val();
        var date_from = $('#datefrom').val();
        var date_to = $('#dateto').val();
        var url = $("#_url").val();

        $.ajax({
            url: url + '/get/employee-schedules/',type: 'get',dataType: 'json',data: {id: emp_id},headers: { 'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') },

            success: function(response) {
                showdata(response);
                function showdata(jsonresponse) {
                    var employee = jsonresponse;
                    var tbody = $('#dataTables-example tbody');
                    
                    // clear data and destroy datatable
                    $('#dataTables-example').DataTable().destroy();
                    tbody.children('tr').remove();

                    // append table row data
                    for (var i = 0; i < employee.length; i++) {
                        var datefrom = employee[i].datefrom;
                        var dateto = employee[i].dateto;
                        function f_date(format_date)
                        {
                            date = new Date(format_date);
                            year = date.getFullYear();
                            month = date.getMonth();
                            months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
                            d = date.getDate();
                            day = date.getDay();
                            days = new Array('Sunday,', 'Monday,', 'Tuesday,', 'Wednesday,', 'Thursday,', 'Friday,', 'Saturday,');
                            
                            n_date = days[day]+' '+months[month]+' '+d+', '+year;
                            return n_date; 
                        }

                        var a = employee[i].archive;
                        function s(a) {
                            if (a == '0') {
                                return '<span class="green">Present Schedule</span>';
                            } else {
                                return '<span class="teal">Past Schedule</span>';
                            }
                        }

                        tbody.append("<tr>" + 
                                            "<td>"+employee[i].employee+"</td>" + 
                                            "<td>"+employee[i].intime+"</td>" + 
                                            "<td>"+employee[i].outime+"</td>" + 
                                            "<td>"+ f_date(datefrom) +"</td>" + 
                                            "<td>"+ f_date(dateto) +"</td>" + 
                                            "<td>"+employee[i].hours+"</td>" + 
                                            "<td>"+employee[i].restday+"</td>" + 
                                            "<td>"+ s(a) +"</td>" + 
                                    "</tr>");
                    }

                    // initialize datatable
                    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: false,ordering: true});
                }            
            }
        })
    });
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/reports/report-employee-schedule.blade.php ENDPATH**/ ?>