    <?php $__env->startSection('meta'); ?>
        <title>Update Account | Workday Time Clock</title>
        <meta name="description" content="Workday update your profile.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__("Update Account")); ?></h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="box box-success">
                    <div class="box-content">
                        <?php if($errors->any()): ?>
                        <div class="ui error message">
                            <i class="close icon"></i>
                            <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                            <ul class="list">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <form action="<?php echo e(url('user/update-profile')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="field">
                            <label><?php echo e(__("Name")); ?></label>
                            <input type="text" name="name" value="<?php if(isset($myuser->name)): ?><?php echo e($myuser->name); ?><?php endif; ?>" class="uppercase">
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("Email")); ?></label>
                            <input type="email" name="email" value="<?php if(isset($myuser->email)): ?><?php echo e($myuser->email); ?><?php endif; ?>" class="lowercase">
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("Role")); ?></label>
                        <input type="text" class="readonly uppercase" value="<?php if(isset($myrole)): ?><?php echo e($myrole); ?><?php endif; ?>" readonly="" />
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("Status")); ?></label>
                            <input type="text" class="readonly uppercase" value="<?php if(isset($myuser->status)): ?><?php if($myuser->status == 1): ?>Enabled <?php else: ?> Disabled <?php endif; ?> <?php endif; ?>" readonly="" />
                        </div>
                    </div>
                    <div class="box-footer">
                        <button class="ui positive button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Update")); ?></button>
                        <a class="ui grey button" href="<?php echo e(url('dashboard')); ?>"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/update-profile.blade.php ENDPATH**/ ?>