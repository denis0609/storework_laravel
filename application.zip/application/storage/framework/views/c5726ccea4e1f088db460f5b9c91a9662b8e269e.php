    
    <?php $__env->startSection('meta'); ?>
        <title>Edit Employee Attendance | Workday Time Clock</title>
        <meta name="description" content="Workday edit employee attendance.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('styles'); ?>
        <link href="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__('Edit Attendance')); ?></h2>
            </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                    <?php if($errors->any()): ?>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"><?php echo e(__('There were some errors with your submission')); ?></div>
                        <ul class="list">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form id="edit_attendance_form" action="<?php echo e(url('attendance/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>
                    <?php if($a->timeout != null): ?>
                        <div class="two fields">
                            <div class="field">
                                <label><?php echo e(__('Employee')); ?></label>
                                <input type="text" name="employee" class="readonly" readonly="" value="<?php if(isset($a->employee)): ?><?php echo e($a->employee); ?><?php endif; ?>">
                            </div>
                            <div class="field">
                                <label for=""><?php echo e(__('Date')); ?></label>
                                <input class="readonly" type="text" placeholder="Date" name="date" value="<?php if(isset($a->date)): ?><?php echo e($a->date); ?><?php endif; ?>" readonly="" />
                            </div>
                        </div>
                    <?php else: ?> 
                        <div class="field">
                            <label><?php echo e(__('Employee')); ?></label>
                            <input type="text" name="employee" class="readonly" readonly="" value="<?php if(isset($a->employee)): ?><?php echo e($a->employee); ?><?php endif; ?>">
                        </div>
                    <?php endif; ?>
                    
                    <?php if($a->timeout != null): ?>
                        <div class="field">
                            <label for=""><?php echo e(__('Time In')); ?></label>
                            <?php if(isset($a->timein)): ?> 
                                <?php 
                                    if($tf == 1) {
                                        $t_in = date("h:i:s A",strtotime($a->timein)); 
                                    } else {    
                                        $t_in = date("H:i:s",strtotime($a->timein)); 
                                    }
                                    $t_in_date = date("m/d/Y",strtotime($a->timein)); 
                                ?>
                            <?php endif; ?>
                            <input type="hidden" name="timein_date" value="<?php if(isset($t_in_date)): ?><?php echo e($t_in_date); ?><?php endif; ?>">
                            <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timein" value="<?php if(isset($t_in)): ?><?php echo e($t_in); ?><?php endif; ?>"/>
                        </div>
                    <?php else: ?>
                        <div class="two fields">
                            <div class="field">
                                <label for=""><?php echo e(__('Time In')); ?></label>
                                <?php if(isset($a->timein)): ?> 
                                    <?php 
                                        if($tf == 1) {
                                            $t_in = date("h:i:s A",strtotime($a->timein)); 
                                        } else {    
                                            $t_in = date("H:i:s",strtotime($a->timein)); 
                                        }
                                        $t_in_date = date("m/d/Y",strtotime($a->timein)); 
                                    ?>
                                <?php endif; ?>
                                <input type="hidden" name="timein_date" value="<?php if(isset($t_in_date)): ?><?php echo e($t_in_date); ?><?php endif; ?>">
                                <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timein" value="<?php if(isset($t_in)): ?><?php echo e($t_in); ?><?php endif; ?>"/>
                            </div>
                            <div class="field">
                                <label for=""><?php echo e(__('Time In Date')); ?></label>
                                <input class="readonly" type="text" placeholder="Date" name="date" value="<?php if(isset($a->date)): ?><?php echo e($a->date); ?><?php endif; ?>" readonly="" />
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($a->timeout != null): ?>
                        <div class="field">
                            <label for=""><?php echo e(__('Time Out')); ?></label>
                                <?php 
                                    if($tf == 1) {
                                        $t_out = date("h:i:s A",strtotime($a->timeout)); 
                                    } else {    
                                        $t_out = date("H:i:s",strtotime($a->timeout)); 
                                    }
                                    $t_out_date = date("m/d/Y",strtotime($a->timeout)); 
                                ?>
                            <input type="hidden" name="timeout_date" value="<?php if($a->timeout != null): ?><?php echo e($t_out_date); ?><?php endif; ?>">
                            <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timeout" value="<?php if($a->timeout != null): ?><?php echo e($t_out); ?><?php endif; ?>"/>
                        </div>
                    <?php else: ?>
                        <div class="two fields">
                            <div class="field">
                                <label for=""><?php echo e(__('Time Out')); ?></label>
                                <?php if(isset($a->timeout)): ?> 
                                    <?php 
                                        if($tf == 1) {
                                            $t_out = date("h:i:s A",strtotime($a->timeout)); 
                                        } else {    
                                            $t_out = date("H:i:s",strtotime($a->timeout)); 
                                        }
                                        $t_out_date = date("m/d/Y",strtotime($a->timeout)); 
                                    ?>
                                <?php endif; ?>
                                <input type="hidden" name="timeout_date" value="<?php if($a->timeout != null): ?><?php echo e($t_out_date); ?><?php endif; ?>">
                                <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timeout" value="<?php if($a->timeout != null): ?><?php echo e($t_out); ?><?php endif; ?>"/>
                            </div>
                            <div class="field">
                                <label for=""><?php echo e(__('Time Out Date')); ?></label>
                                <input type="text" name="timeout_date" value="" class="airdatepicker">
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="fields">
                        <div class="sixteen wide field">
                            <label><?php echo e(__('Reason')); ?></label>
                            <textarea class="" rows="5" name="reason"><?php if(isset($a->reason)): ?><?php echo e($a->reason); ?><?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="field">
                        <div class="ui error message">
                            <i class="close icon"></i>
                            <div class="header"></div>
                            <ul class="list">
                                <li class=""></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="box-footer">
                    <input type="hidden" name="id" value="<?php if(isset($e_id)): ?><?php echo e($e_id); ?><?php endif; ?>">
                    <input type="hidden" name="idno" value="<?php if(isset($a->idno)): ?><?php echo e($a->idno); ?><?php endif; ?>">
                    <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__('Update')); ?></button>
                    <a class="ui grey small button" href="<?php echo e(url('attendance')); ?>"><i class="ui times icon"></i> <?php echo e(__('Cancel')); ?></a>
                </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    
    <script type="text/javascript">
    <?php if(isset($tf)): ?>
        <?php if($tf == 1): ?>
            mdtimepicker('.jtimepicker', { format:'h:mm tt', theme: 'blue', hourPadding: true });
        <?php else: ?>
            mdtimepicker('.jtimepicker', { format:'hh:mm', theme: 'blue', hourPadding: true });
        <?php endif; ?>
    <?php endif; ?>
    
    $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/edits/edit-attendance.blade.php ENDPATH**/ ?>