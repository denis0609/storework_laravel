    <?php $__env->startSection('meta'); ?>
        <title>Reports | Workday Time Clock</title>
        <meta name="description" content="Workday reports, view reports, and export or download reports.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__("User Accounts Report")); ?>

                <a href="<?php echo e(url('export/report/accounts')); ?>" class="ui basic button mini offsettop5 btn-export float-right"><i class="ui icon download"></i><?php echo e(__("Export to CSV")); ?></a>
                <a href="<?php echo e(url('reports')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i><?php echo e(__("Return")); ?></a>
            </h2> 
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__("Employee Name")); ?></th>
                                <th><?php echo e(__("Email")); ?></th>
                                <th><?php echo e(__("Account Type")); ?></th>
                                <th><?php echo e(__("Status")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($userAccs)): ?>
                                <?php $__currentLoopData = $userAccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($v->name); ?></td>
                                        <td><?php echo e($v->email); ?></td>
                                        <td><?php if( $v->acc_type == 2): ?> Admin <?php else: ?> Employee <?php endif; ?></td>
                                        <td><?php if($v->status == 1): ?> Active <?php endif; ?> <?php if($v->status == 0): ?> Disabled <?php endif; ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/reports/report-user-accounts.blade.php ENDPATH**/ ?>