<!doctype html>
<!--
* Workday - A time clock application for employees
* Support: official.codefactor@gmail.com
* Version: 1.6
* Author: Brian Luna
* Copyright 2020 Codefactor
-->
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/assets/images/img/favicon-16x16.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/assets/images/img/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/assets/images/img/favicon.ico')); ?>">
        
        <title>Web Time Clock | Workday Time Clock</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/clock.css')); ?>">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="<?php echo e(asset('/assets/vendor/html5shiv/html5shiv.min.js')); ?>></script>
            <script src="<?php echo e(asset('/assets/vendor/respond/respond.min.js')); ?>"></script>
        <![endif]-->

        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>

    <img src="<?php echo e(asset('/assets/images/img/clock-background.png')); ?>" class="wave">
    <div class="wrapper">
        <div id="body">
            <div class="content">

                <?php echo $__env->yieldContent('content'); ?>
             
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/momentjs/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/momentjs/moment-timezone-with-data.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>

    <script>
        var timezone = "<?php if(isset($tz)): ?><?php echo e($tz); ?><?php endif; ?>";
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html><?php /**PATH /home/nacitdsu/entradas.nacionalcode.ink/application/resources/views/layouts/clock.blade.php ENDPATH**/ ?>