    <?php $__env->startSection('meta'); ?>
        <title>Job Titles | Workday Time Clock</title>
        <meta name="description" content="Workday job titles, view job titles, and export or download job titles.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-import-jobtitle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h2 class="page-title"><?php echo e(__("Add Job Title")); ?>

                <button class="ui basic button mini offsettop5 btn-import float-right"><i class="ui icon upload"></i> <?php echo e(__("Import")); ?></button>
                <a href="<?php echo e(url('export/fields/jobtitle' )); ?>" class="ui basic button mini offsettop5 btm-export float-right"><i class="ui icon download"></i> <?php echo e(__("Export")); ?></a>
            </h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="box box-success">
                <div class="box-body">
                    <?php if($errors->any()): ?>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                        <ul class="list">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form id="add_jobtitle_form" action="<?php echo e(url('fields/jobtitle/add')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="field">
                            <label><?php echo e(__("Department")); ?></label>
                            <select name="department" class="ui search dropdown getdeptcode">
                                <option value="">Select Department</option>
                                <?php if(isset($d)): ?>
                                    <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->department); ?>" data-id="<?php echo e($dept->id); ?>"> <?php echo e($dept->department); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="field">
                            <label><?php echo e(__("Job Title")); ?> <span class="help">e.g. "Chief Executive Officer"</span></label>
                            <input class="uppercase" name="jobtitle" value="" type="text" value="">
                        </div>
                        <div class="field">
                            <div class="ui error message">
                                <i class="close icon"></i>
                                <div class="header"></div>
                                <ul class="list">
                                    <li class=""></li>
                                </ul>
                            </div>
                        </div>
                        <div class="actions">
                            <input type="hidden" name="dept_code" value="">
                            <button type="submit" class="ui positive button small"><i class="ui icon check"></i> <?php echo e(__("Save")); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 1, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__("Job Title")); ?></th>
                                <th><?php echo e(__("Department")); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($j->jobtitle); ?></td>
                                <td>
                                    <?php if(isset($d)): ?>
                                        <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($j->dept_code == $dept->id): ?>
                                                <?php echo e($dept->department); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td class="align-right"><a href="<?php echo e(url('fields/jobtitle/delete/'.$j->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});

    $('.ui.dropdown.getdeptcode').dropdown({
        onChange: function (value, text, $selectedItem) {
            $('select[name="department"] option').each(function () {
                if ($(this).val() == value) {
                    var id = $(this).attr('data-id');
                    $('input[name="dept_code"]').val(id);
                };
            });
        }
    });

    function validateFile() {
        var f = document.getElementById("csvfile").value;
        var d = f.lastIndexOf(".") + 1;
        var ext = f.substr(d, f.length).toLowerCase();
        if (ext == "csv") {} else {
            document.getElementById("csvfile").value = "";
            $.notify({
                icon: 'ui icon times',
                message: "Please upload only CSV file format."
            }, {
                type: 'danger',
                timer: 400
            });
        }
    }
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/fields/jobtitle.blade.php ENDPATH**/ ?>