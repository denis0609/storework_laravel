<div class="ui modal add medium">
    <div class="header"><?php echo e(__("Add New Schedule")); ?></div>
    <div class="content">
        <form id="add_schedule_form" action="<?php echo e(url('schedules/add')); ?>" class="ui form" method="post" accept-charset="utf-8">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label><?php echo e(__('Employee')); ?></label>
                <select class="ui search dropdown getid uppercase" name="employee">
                    <option value="">Select Employee</option>
                    <?php if(isset($employee)): ?>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?>" data-id="<?php echo e($data->id); ?>"><?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="two fields">
                <div class="field">
                    <label for=""><?php echo e(__('Start time')); ?></label>
                    <input type="text" placeholder="00:00:00 AM" name="intime" class="jtimepicker" />
                </div>
                <div class="field">
                    <label for=""><?php echo e(__('Off time')); ?></label>
                    <input type="text" placeholder="00:00:00 PM" name="outime" class="jtimepicker" />
                </div>
            </div>
            <div class="field">
                <label for=""><?php echo e(__('From')); ?></label>
                <input type="text" placeholder="Date" name="datefrom" id="datefrom" class="airdatepicker" />
            </div>
            <div class="field">
                <label for=""><?php echo e(__('To')); ?></label>
                <input type="text" placeholder="Date" name="dateto" id="dateto" class="airdatepicker" />
            </div>
            <div class="eight wide field">
                <label for=""><?php echo e(__('Total hours')); ?></label>
                <input type="number" placeholder="0" name="hours" />
            </div>
           <div class="grouped fields field">
                <label><?php echo e(__('Choose Rest days')); ?></label>
                <div class="field">
                    <div class="ui checkbox sunday">
                        <input type="checkbox" name="restday[]" value="Sunday">
                        <label><?php echo e(__('Sunday')); ?></label>
                    </div>
                </div>
                <div class="field">
                    <div class="ui checkbox ">
                        <input type="checkbox" name="restday[]" value="Monday">
                        <label><?php echo e(__('Monday')); ?></label>
                    </div>
                </div>
                <div class="field">
                    <div class="ui checkbox ">
                        <input type="checkbox" name="restday[]" value="Tuesday">
                        <label><?php echo e(__('Tuesday')); ?></label>
                    </div>
                </div>
                <div class="field">
                    <div class="ui checkbox ">
                        <input type="checkbox" name="restday[]" value="Wednesday">
                        <label><?php echo e(__('Wednesday')); ?></label>
                    </div>
                </div>
                <div class="field">
                    <div class="ui checkbox ">
                        <input type="checkbox" name="restday[]" value="Thursday">
                        <label><?php echo e(__('Thursday')); ?></label>
                    </div>
                </div>
                <div class="field">
                    <div class="ui checkbox ">
                        <input type="checkbox" name="restday[]" value="Friday">
                        <label><?php echo e(__('Friday')); ?></label>
                    </div>
                </div>
                <div class="field" style="padding:0">
                    <div class="ui checkbox saturday">
                        <input type="checkbox" name="restday[]" value="Saturday">
                        <label><?php echo e(__('Saturday')); ?></label>
                    </div>
                </div>
                <div class="ui error message">
                    <i class="close icon"></i>
                    <div class="header"></div>
                    <ul class="list">
                        <li class=""></li>
                    </ul>
                </div>
            </div>
        </div>
            
        <div class="actions">
            <input type="hidden" name="id" value="">
            <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__('Save')); ?></button>
            <button class="ui grey small button cancel" type="button"><i class="ui times icon"></i> <?php echo e(__('Cancel')); ?></button>
        </div>
        </form>  
</div>
<?php /**PATH /home/nacitdsu/producciones.nacionalcode.ink/application/resources/views/admin/modals/modal-add-schedule.blade.php ENDPATH**/ ?>